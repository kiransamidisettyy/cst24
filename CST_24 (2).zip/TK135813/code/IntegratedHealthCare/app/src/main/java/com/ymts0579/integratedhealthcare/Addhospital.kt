package com.ymts0579.integratedhealthcare

import android.location.Geocoder
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class Addhospital : Fragment() {

    lateinit var ethname: EditText
    lateinit var ethnum: EditText
    lateinit var ethaddress: EditText
    lateinit var ethcity: EditText
    lateinit var ethbeds: EditText
    lateinit var ethrating: EditText
    lateinit var ethdept:EditText
    lateinit var btnaddhospital: Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var view=inflater.inflate(R.layout.fragment_addhospital, container, false)
        ethname=view.findViewById(R.id.ethname)
        ethnum=view.findViewById(R.id.ethnum)
        ethaddress=view.findViewById(R.id.ethaddress)
        ethcity=view.findViewById(R.id.ethcity)
        ethbeds=view.findViewById(R.id.ethbeds)
        ethrating=view.findViewById(R.id.ethpass)
        ethdept=view.findViewById(R.id.ethdept)
        btnaddhospital=view.findViewById(R.id.btnaddhospital)




        btnaddhospital.setOnClickListener {
            val name=ethname.text.toString()
            val num=ethnum.text.toString()
            val add=ethaddress.text.toString()
            val city=ethcity.text.toString()
            val email=ethbeds.text.toString()
            val pass=ethrating.text.toString()
            val dept=ethdept.text.toString()

            if(name.isEmpty()&& num.isEmpty()&& add.isEmpty()&&city.isEmpty()&&email.isEmpty()
                && pass.isEmpty()){
                ethname.setError("Enter hospital name ")
                ethnum.setError("Enter hospital number")
                ethaddress.setError("Enter hospital address")
                ethcity.setError("Enter hospital city")
                ethbeds.setError("Enter hospital beds")
                ethrating.setError("Enter hospital rating")

            }else{
                if(num.count()==10){


                    CoroutineScope(Dispatchers.IO).launch {

                        RetrofitClient.instance.register("Hospital","$name","$num","$email",
                            "$city","$pass","$add","Open",dept,"register")
                            .enqueue(object: Callback<DefaultResponse> {
                                override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                    t.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show() }
                                }
                                override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                    response.body()?.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show()}
                                    Toast.makeText(context, response.body()!!.message, Toast.LENGTH_SHORT).show()
                                   /* ethname.text!!.clear()
                                    ethnum.text!!.clear()
                                    ethaddress.text!!.clear()
                                    ethcity.text!!.clear()
                                    ethbeds.text!!.clear()
                                    ethrating.text!!.clear()*/
                                }
                            })
                    }

                    //Toast.makeText(activity, "$lat,$long,$name,$num,$add,$city,$beds,$depart,$rating,", Toast.LENGTH_SHORT).show()
                }else{
                    ethnum.setError("Enter hospital number properly")
                    Toast.makeText(activity,"Enter hospital number properly", Toast.LENGTH_SHORT).show()
                }
            }

        }

        return view
    }


}