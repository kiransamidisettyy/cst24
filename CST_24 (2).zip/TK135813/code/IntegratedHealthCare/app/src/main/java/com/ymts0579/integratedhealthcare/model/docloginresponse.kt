package com.ymts0579.integratedhealthcare.model

import com.ymts0579.model.model.User

class docloginresponse(val error: Boolean, val message:String,var user: doctors) {
}