package com.ymts0579.integratedhealthcare.model

import com.ymts0579.model.model.User

class doctorresponse(val error: Boolean, val message:String, var user:ArrayList<doctors>) {
}