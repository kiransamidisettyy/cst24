package com.ymts0579.integratedhealthcare.Admin

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.fragment.app.Fragment
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.ymts0579.integratedhealthcare.Addhospital
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.adminhome
import com.ymts0579.integratedhealthcare.viewadminhosiptal

class Admindashboard : AppCompatActivity() {
    lateinit var fragment: Fragment
    lateinit var bottomNav: BottomNavigationView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_hospital)
        bottomNav = findViewById(R.id.bottomNav) as BottomNavigationView
        bottom()


        fragment=adminhome()
        callingFragment(fragment)
    }

    private fun bottom() {
        bottomNav.setOnItemSelectedListener {

            when (it.itemId) {
                R.id.home->{
                  fragment=adminhome()
                    callingFragment(fragment)
                    true
                }
                R.id.Addhospital -> {
                    fragment= Addhospital()
                    callingFragment(fragment)
                    true
                }
                R.id.viewhospital->{
                    fragment= viewadminhosiptal()
                    callingFragment(fragment)
                    true
                }
                else -> {
                    false
                }
            }
        }

    }

    private fun callingFragment(fragment: Fragment) {

        val fragmentManager=supportFragmentManager
        val fragmentTransaction=fragmentManager.beginTransaction()
        fragmentTransaction.replace(R.id.fcontainer, fragment)
        fragmentTransaction.addToBackStack(null)
        fragmentTransaction.commit()
    }
}