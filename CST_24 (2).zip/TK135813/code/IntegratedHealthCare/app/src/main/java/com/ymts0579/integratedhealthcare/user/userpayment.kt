package com.ymts0579.integratedhealthcare.user

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.ymts0579.integratedhealthcare.R
import dev.shreyaspatil.easyupipayment.EasyUpiPayment
import dev.shreyaspatil.easyupipayment.listener.PaymentStatusListener
import dev.shreyaspatil.easyupipayment.model.PaymentApp
import dev.shreyaspatil.easyupipayment.model.TransactionDetails
import dev.shreyaspatil.easyupipayment.model.TransactionStatus
import kotlinx.android.synthetic.main.activity_userpayment.*

class userpayment : AppCompatActivity() , PaymentStatusListener {
    private lateinit var easyUpiPayment: EasyUpiPayment
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_userpayment)
        btnpayment.setOnClickListener {
            initViews()

        }
    }
    private fun initViews() {
        val transactionId = "TID" + System.currentTimeMillis()
        ettranscation.setText(transactionId)
        etreqtransaction.setText(transactionId)
        btnpayment.setOnClickListener {pay()}
    }

    private fun pay() {
        var upi=etupiid1.text.toString()
        var amount=etamount.text.toString()
        var tran=ettranscation.text.toString()
        var tranreg=etreqtransaction.text.toString()
        var dec=etdec.text.toString()
        var nam=etname.text.toString()
        var payeeMerchantCode = field_payee_merchant_code.text.toString()
        val paymentAppChoice = radioAppChoice

        val paymentApp = when (paymentAppChoice.checkedRadioButtonId) {
            R.id.app_default -> PaymentApp.ALL
            R.id.app_google_pay -> PaymentApp.GOOGLE_PAY
            R.id.app_phonepe -> PaymentApp.PHONE_PE
            R.id.app_paytm -> PaymentApp.PAYTM
            else -> throw IllegalStateException("Unexpected value: " + paymentAppChoice.id)
        }

        try {
            // START PAYMENT INITIALIZATION
            easyUpiPayment = EasyUpiPayment(this) {
                this.paymentApp = paymentApp
                this.payeeVpa = upi
                this.payeeName = nam
                this.transactionId = tran
                this.transactionRefId = tranreg
                this.payeeMerchantCode = payeeMerchantCode
                this.description = dec
                this.amount = amount
            }
            easyUpiPayment.setPaymentStatusListener(this)
            easyUpiPayment.startPayment()
        } catch (e: Exception) {
            e.printStackTrace()

            Toast.makeText(this, "Error: ${e.message}", Toast.LENGTH_SHORT).show()

        }

    }
    override fun onTransactionCancelled() {
        toast("Cancelled by user")
    }

    override fun onTransactionCompleted(transactionDetails: TransactionDetails) {
        tvustatus1.text = transactionDetails.toString()

        when (transactionDetails.transactionStatus) {
            TransactionStatus.SUCCESS -> onTransactionSuccess()
            TransactionStatus.FAILURE -> onTransactionFailed()
            TransactionStatus.SUBMITTED -> onTransactionSubmitted()
        }
    }

    private fun onTransactionSubmitted() {
        toast("Pending | Submitted")
    }

    private fun onTransactionFailed() {
        toast("Failed")
    }

    private fun onTransactionSuccess() {
        toast("Success")
    }

    private fun toast(message: String) {
        Toast.makeText(this, message, Toast.LENGTH_SHORT).show()
    }

}