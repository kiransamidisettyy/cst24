package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.user.userviewdoctor

import com.ymts0579.model.model.User

class userhosadapter(var context: Context, var listdata: ArrayList<User>): RecyclerView.Adapter<userhosadapter.DataViewHolder>(){
    var id=0
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val  tvname=view.findViewById<TextView>(R.id.tvname)
        val  tvnum=view.findViewById<TextView>(R.id.tvnum)
        val tvcity=view.findViewById<TextView>(R.id.tvcity)
        val tvstatus=view.findViewById<TextView>(R.id.tvstatus)
        val tvdep=view.findViewById<TextView>(R.id.tvdep)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.userhospital, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
        holder.tvname.text=listdata[position].name
        holder.tvnum.text=listdata[position].moblie
        holder.tvcity.text=listdata[position].address
        holder.tvstatus.text=listdata[position].status
        holder.tvdep.text=listdata[position].service


        holder.itemView.setOnClickListener {
            var ii=Intent(context,userviewdoctor::class.java)
            ii.putExtra("email",listdata[position].email)
            ii.putExtra("address",listdata[position].address)
            context.startActivity(ii)
        }


    }




    override fun getItemCount() = listdata.size
}
