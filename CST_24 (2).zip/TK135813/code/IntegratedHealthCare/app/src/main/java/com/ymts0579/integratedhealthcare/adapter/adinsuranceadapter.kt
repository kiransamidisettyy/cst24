package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.model.Appointments
import com.ymts0579.integratedhealthcare.model.insurance
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class adinsuranceadapter(var context: Context, var listdata: ArrayList<insurance>):
    RecyclerView.Adapter<adinsuranceadapter.DataViewHolder>(){
    var id=0
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
       val tviname=view.findViewById<TextView>(R.id.tviname)
       val tvinum=view.findViewById<TextView>(R.id.tvinum)
       val tviaddress=view.findViewById<TextView>(R.id.tviaddress)
       val tvides=view.findViewById<TextView>(R.id.tvides)
        val viewimg=view.findViewById<ImageView>(R.id.viewimg)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.insurancecard, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
        holder.tviname.text=listdata[position].name
        holder.tvinum.text=listdata[position].moblie
        holder.tviaddress.text=listdata[position].address
        holder.tvides.text=listdata[position].service
        val uri= Uri.parse(listdata[position].path.trim())
        Glide.with(context).load(uri).into(holder.viewimg)

        holder.itemView.setOnClickListener {
            id=listdata[position].id
            var alertdialog= AlertDialog.Builder(context)
            alertdialog.setIcon(R.drawable.ic_launcher_foreground)
            alertdialog.setTitle("Delete Insurance")
            alertdialog.setIcon(R.drawable.care)
            alertdialog.setCancelable(false)
            alertdialog.setMessage("Do you Want to Delete Insurance?")
            alertdialog.setPositiveButton("Yes"){ alertdialog, which->
                deletepath(id)
                alertdialog.dismiss()
            }
            alertdialog.setNegativeButton("No"){alertdialog,which->
                Toast.makeText(context,"thank you", Toast.LENGTH_SHORT).show()
                alertdialog.dismiss()
            }
            alertdialog.show()
        }


    }

    private fun deletepath(id: Int) {
        CoroutineScope(Dispatchers.IO).launch {
            RetrofitClient.instance.deleteinsurance(id,"deleteperson")
                .enqueue(object : Callback<DefaultResponse> {
                    override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                        Toast.makeText(context, response.body()!!.message, Toast.LENGTH_SHORT).show()
                    }

                    override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                        Toast.makeText(context, "${t.message}", Toast.LENGTH_SHORT).show()

                    }

                })
        }

    }


    override fun getItemCount() = listdata.size
}