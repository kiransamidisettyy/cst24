package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.model.Appointments

class hosappointadapter(var context: Context, var listdata: ArrayList<Appointments>): RecyclerView.Adapter<hosappointadapter.DataViewHolder>(){
    var id=0
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {

        val tvappid=view.findViewById<TextView>(R.id.tvappid)
        val tvdname=view.findViewById<TextView>(R.id.tvdname)
        val tvatime=view.findViewById<TextView>(R.id.tvatime)
        val tvastatus=view.findViewById<TextView>(R.id.tvastatus)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.happointments, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {

        holder.tvappid.text=listdata[position].appointid
        holder.tvdname.text=listdata[position].Dname
        holder.tvatime.text=listdata[position].date
        holder.tvastatus.text=listdata[position].status

    }




    override fun getItemCount() = listdata.size
}