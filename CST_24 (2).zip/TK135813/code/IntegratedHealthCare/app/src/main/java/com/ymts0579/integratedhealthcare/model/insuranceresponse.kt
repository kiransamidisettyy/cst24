package com.ymts0579.integratedhealthcare.model

class insuranceresponse(val error: Boolean, val message:String, var user:ArrayList<insurance>) {
}