package com.ymts0579.integratedhealthcare.user

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.aicte.model.hospitalresponse
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.adapter.hospitaladapter
import com.ymts0579.integratedhealthcare.adapter.userhosadapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class useraddappoint : AppCompatActivity() {

    lateinit var  ethospital:EditText
    lateinit var btnshow:Button
    lateinit var listhospials:RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_useraddappoint)
        ethospital=findViewById(R.id.ethospital)
        btnshow=findViewById(R.id.btnshow)
        listhospials=findViewById(R.id.listhospials)
        listhospials.layoutManager = LinearLayoutManager(this)
        listhospials.setHasFixedSize(true)


        btnshow.setOnClickListener {
            var iii=ethospital.text.toString()


            if(iii.isEmpty()){
                ethospital.setError("Enter place")
            }else{
            CoroutineScope(Dispatchers.IO).launch {
                RetrofitClient.instance.readbyplace("placehospitals", iii)
                    .enqueue(object: Callback<hospitalresponse> {
                        override fun onFailure(call: Call<hospitalresponse>, t: Throwable) {

                            Toast.makeText(this@useraddappoint, t.message, Toast.LENGTH_SHORT).show()
                        }
                        override fun onResponse(call: Call<hospitalresponse>, response: Response<hospitalresponse>) {
                            Toast.makeText(this@useraddappoint, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()

                             listhospials.adapter=userhosadapter(this@useraddappoint,response.body()!!.user)
                        }
                    })
            }}
        }
    }
}