package com.ymts0579.integratedhealthcare.user

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.ymts0579.integratedhealthcare.R


class userhome : Fragment() {

    lateinit var  btnuserapp:Button
    lateinit var  btnuappstatus:Button
    lateinit var btnulife:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        val ii=inflater.inflate(R.layout.fragment_userhome, container, false)
        btnuserapp=ii.findViewById(R.id.btnuserapp)
        btnuappstatus=ii.findViewById(R.id.btnuappstatus)
        btnulife=ii.findViewById(R.id.btnulife)

        btnuserapp.setOnClickListener { startActivity(Intent(activity,useraddappoint::class.java)) }
        btnuappstatus.setOnClickListener { startActivity(Intent(activity,viewuserappointmentstatus::class.java))  }
        btnulife.setOnClickListener { startActivity(Intent(activity,Userinsurance::class.java)) }
        return ii
    }


}