package com.ymts0579.integratedhealthcare

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import com.ymts0579.integratedhealthcare.Admin.AdminFeedback


class adminhome : Fragment() {
    lateinit var adminlogout:Button
    lateinit var btnadminfeed:Button
    lateinit var btnadmininsurance:Button

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       val view=inflater.inflate(R.layout.fragment_adminhome, container, false)
        adminlogout=view.findViewById(R.id.adminlogout)
        btnadminfeed=view.findViewById(R.id.btnadminfeed)
        btnadmininsurance=view.findViewById(R.id.btnadmininsurance)


        btnadminfeed.setOnClickListener { startActivity(Intent(activity,AdminFeedback::class.java)) }
        btnadmininsurance.setOnClickListener { startActivity(Intent(activity,adminhealthcare::class.java)) }
        adminlogout.setOnClickListener {
            var alertdialog= context?.let { it1 -> AlertDialog.Builder(it1) }!!
            alertdialog.setIcon(R.drawable.ic_launcher_foreground)
            alertdialog.setTitle("LOGOUT")
            alertdialog.setIcon(R.drawable.care)
            alertdialog.setCancelable(false)
            alertdialog.setMessage("Do you Want to Logout?")
            alertdialog.setPositiveButton("Yes"){ alertdialog, which->
                startActivity(Intent(context, login::class.java))
                    requireActivity().finish()
                val  shared=this.requireActivity().getSharedPreferences("admin", AppCompatActivity.MODE_PRIVATE)
                shared.edit().clear().apply()
                alertdialog.dismiss()
            }
            alertdialog.setNegativeButton("No"){alertdialog,which->
                Toast.makeText(context,"thank you", Toast.LENGTH_SHORT).show()
                alertdialog.dismiss()
            }
            alertdialog.show()
        }
        return view
    }


}