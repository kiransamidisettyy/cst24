package com.ymts0579.integratedhealthcare.model

class Appointments(
    var id:Int,
    var appointid:String,
    var hemail:String,
   var  haddress:String,
    var Dname:String,
    var Dnumber:String,
    var uemail:String,
   var  unum:String,
   var  uname:String,
   var  hours:String,
   var  date:String,
   var  cost:String,
   var  status:String,
   var  pstatus:String,
   var  transactionid:String,
   var  feedback:String,
    var reason:String,
) {
}