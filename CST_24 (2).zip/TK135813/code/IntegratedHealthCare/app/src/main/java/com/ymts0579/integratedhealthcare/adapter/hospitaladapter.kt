package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView

import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.model.model.DefaultResponse
import com.ymts0579.model.model.User
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class hospitaladapter(var context: Context, var listdata: ArrayList<User>): RecyclerView.Adapter<hospitaladapter.DataViewHolder>(){
    var id=0
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvname=view.findViewById<TextView>(R.id.tvname)
        val tvnum=view.findViewById<TextView>(R.id.tvnum)
        val tvcity=view.findViewById<TextView>(R.id.tvcity)
        val tvdep=view.findViewById<TextView>(R.id.tvdep)
        val tvemail=view.findViewById<TextView>(R.id.tvemail)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.ad_hospital, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
        holder.tvname.text=listdata[position].name
        holder.tvnum.text=listdata[position].moblie
        holder.tvcity.text=listdata[position].city
        holder.tvdep.text=listdata[position].service
        holder.tvemail.text=listdata[position].email


    }




    override fun getItemCount() = listdata.size
}
