package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.telephony.gsm.SmsManager
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.model.Appointments
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class docadapter(var context: Context, var listdata: ArrayList<Appointments>):
    RecyclerView.Adapter<docadapter.DataViewHolder>(){
    var id=0
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val  tvuapid=view.findViewById<TextView>(R.id.tvuapid)
        val  tvudoc=view.findViewById<TextView>(R.id.tvudoc)
        val  tvudnum=view.findViewById<TextView>(R.id.tvudnum)
        val  tvutime=view.findViewById<TextView>(R.id.tvutime)
        val  tvuhours=view.findViewById<TextView>(R.id.tvuhours)
        val   tvucost=view.findViewById<TextView>(R.id.tvucost)
        val  tvustatus=view.findViewById<TextView>(R.id.tvustatus)
        val tvgeneral=view.findViewById<TextView>(R.id.tvgeneral)
        val  tvupay=view.findViewById<TextView>(R.id.tvupay)
        val btndocompletd=view.findViewById<Button>(R.id.btndocompletd)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.docappointmnet, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
        val k=listdata[position]
        holder. tvuapid.text=k.appointid
        holder. tvudoc.text=k.uname
        holder. tvudnum.text=k.unum
        holder. tvutime.text=k.date
        holder. tvuhours.text=k.hours
        holder. tvucost.text=k.cost
        holder. tvustatus.text=k.status
        holder. tvupay.text=k.pstatus
        holder.tvgeneral.text=k.reason
        holder.btndocompletd.setOnClickListener {
            id=listdata[position].id
            var num=listdata[position].unum
            var alertdialog= AlertDialog.Builder(context)
            alertdialog.setIcon(R.drawable.ic_launcher_foreground)
            alertdialog.setTitle("Completed")
            alertdialog.setIcon(R.drawable.care)
            alertdialog.setMessage("Are you Completed Appointment?")
            alertdialog.setPositiveButton("Completed"){ alertdialog, which->
                var status="Completed"
                rejectAppoint(id,status,num)
                alertdialog.dismiss()
            }

            alertdialog.show()
        }


        holder.itemView.setOnClickListener {
                id=listdata[position].id
                var num=listdata[position].unum
                var alertdialog= AlertDialog.Builder(context)
                alertdialog.setIcon(R.drawable.ic_launcher_foreground)
                alertdialog.setTitle("Accept/Reject")
                alertdialog.setIcon(R.drawable.care)
                alertdialog.setMessage("Are you Accepting the Appointment?")
                alertdialog.setPositiveButton("Yes"){ alertdialog, which->
                    var status="Accepted"
                    rejectAppoint(id,status,num)
                    alertdialog.dismiss()
                }
                alertdialog.setNegativeButton("No"){alertdialog,which->
                    var status="Rejected"
                    rejectAppoint(id,status,num)
                    alertdialog.dismiss()
                }
                alertdialog.show()

        }

    }

    private fun rejectAppoint(id: Int,status:String,num:String) {
        CoroutineScope(Dispatchers.IO).launch {
            RetrofitClient.instance.doctoraccepted("docstatus","$status",id)
                .enqueue(object : Callback<DefaultResponse> {
                    override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                        Toast.makeText(context, t.message, Toast.LENGTH_LONG).show()
                    }
                    override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                        Toast.makeText(context, "${response.body()!!.message},${num}", Toast.LENGTH_SHORT).show()
                        if (TextUtils.isDigitsOnly(num)) {
                            val smsManager: SmsManager = SmsManager.getDefault()
                            smsManager.sendTextMessage(num, null, "your Appointment is ${status}", null, null)

                        }
                    }
                })
        }

    }


    override fun getItemCount() = listdata.size
}