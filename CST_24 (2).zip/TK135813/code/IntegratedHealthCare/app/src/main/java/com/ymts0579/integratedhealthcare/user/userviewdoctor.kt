package com.ymts0579.integratedhealthcare.user

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.adapter.hdoctoadapter
import com.ymts0579.integratedhealthcare.adapter.userdoctoradapter
import com.ymts0579.integratedhealthcare.model.doctorresponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class userviewdoctor : AppCompatActivity() {
    lateinit var  list: RecyclerView
    lateinit var count: TextView
    var eamil=""
    var address=""
    var num=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_userviewdoctor)


        list=findViewById(R.id.adlistdocotors)
        count=findViewById(R.id.count)
        list.layoutManager = LinearLayoutManager(this)
        list.setHasFixedSize(true)

        eamil=intent.getStringExtra("email").toString()
        address=intent.getStringExtra("address").toString()

        CoroutineScope(Dispatchers.IO).launch {

            RetrofitClient.instance.viewdoctor("$eamil","email")
                .enqueue(object: Callback<doctorresponse> {
                    override fun onFailure(call: Call<doctorresponse>, t: Throwable) {

                        Toast.makeText(this@userviewdoctor, t.message, Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(call: Call<doctorresponse>, response: Response<doctorresponse>) {
                        Toast.makeText(this@userviewdoctor, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()

                        list.adapter= userdoctoradapter(this@userviewdoctor,response.body()!!.user,eamil,address)
                        for (item in response.body()!!.user){
                            num++
                        }
                        count.setText("Number of Doctor->$num")
                    }
                })
        }
    }
}