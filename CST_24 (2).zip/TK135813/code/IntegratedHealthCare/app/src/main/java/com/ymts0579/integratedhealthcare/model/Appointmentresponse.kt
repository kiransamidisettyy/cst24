package com.ymts0579.integratedhealthcare.model

class Appointmentresponse(val error: Boolean, val message:String, var user:ArrayList<Appointments>) {
}