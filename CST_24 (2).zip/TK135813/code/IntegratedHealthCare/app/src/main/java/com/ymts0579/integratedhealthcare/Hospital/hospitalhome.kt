package com.ymts0579.integratedhealthcare.Hospital

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import com.ymts0579.integratedhealthcare.R


class hospitalhome : Fragment() {

lateinit var btndoctor:Button
lateinit var btnhosapp:Button
lateinit var btnhosfeedback:Button
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(inflater: LayoutInflater, container: ViewGroup?, savedInstanceState: Bundle?): View? {

        val ii=inflater.inflate(R.layout.fragment_hospitalhome, container, false)
         btndoctor=ii.findViewById(R.id.btndoctor)
        btnhosapp=ii.findViewById(R.id.btnhosapp)
        btnhosfeedback=ii.findViewById(R.id.btnhosfeedback)
        btndoctor.setOnClickListener { startActivity(Intent(activity,Doctor::class.java)) }
        btnhosapp.setOnClickListener { startActivity(Intent(activity,Viewhospitalappoints::class.java)) }
        btnhosfeedback.setOnClickListener { startActivity(Intent(activity,viewfeedbackhosptial::class.java)) }
        return ii
    }


}