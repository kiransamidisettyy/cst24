package com.ymts0579.integratedhealthcare.Admin

import android.app.Notification
import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.adapter.adfeedbackadapter
import com.ymts0579.integratedhealthcare.adapter.hosfeedapadter
import com.ymts0579.integratedhealthcare.model.Appointmentresponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class AdminFeedback : AppCompatActivity() {
    lateinit var  list: RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_admin_feedback)
        list=findViewById(R.id.adlisthosfeeback)
        list.layoutManager = LinearLayoutManager(this)
        list.setHasFixedSize(true)


        CoroutineScope(Dispatchers.IO).launch {

            RetrofitClient.instance.adminfeedback("readall",)
                .enqueue(object: Callback<Appointmentresponse> {
                    override fun onFailure(call: Call<Appointmentresponse>, t: Throwable) {

                        Toast.makeText(this@AdminFeedback, t.message, Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(call: Call<Appointmentresponse>, response: Response<Appointmentresponse>) {
                        Toast.makeText(this@AdminFeedback, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()

                        list.adapter= adfeedbackadapter(this@AdminFeedback,response.body()!!.user)

                    }
                })
        }
    }
}