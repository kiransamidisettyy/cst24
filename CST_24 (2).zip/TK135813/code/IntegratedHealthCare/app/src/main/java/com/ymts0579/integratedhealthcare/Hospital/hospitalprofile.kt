package com.ymts0579.integratedhealthcare.Hospital

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.login
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class hospitalprofile : Fragment(), AdapterView.OnItemSelectedListener {
   lateinit var   ethemail1:EditText
     lateinit var ethname1:EditText
    lateinit var  ethnum1:EditText
     lateinit var ethdept:EditText
     lateinit var ethaddress1:EditText
    lateinit var  ethcity1:EditText
    lateinit var  ethpass1:EditText
     lateinit var btnupdatehospital:Button
     lateinit var spinnerstatus: Spinner
     var sss=""
     var stat= arrayOf("Open","Close")

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        var vv=inflater.inflate(R.layout.fragment_hospitalprofile, container, false)
        ethemail1=vv.findViewById(R.id.ethemail1)
        ethname1=vv.findViewById(R.id.ethname1)
        ethnum1=vv.findViewById(R.id.ethnum1)
        ethdept=vv.findViewById(R.id.ethdept)
        ethaddress1=vv.findViewById(R.id.ethaddress1)
        ethcity1=vv.findViewById(R.id.ethcity1)
        ethpass1=vv.findViewById(R.id.ethpass1)
        btnupdatehospital=vv.findViewById(R.id.btnupdatehospital)
        spinnerstatus=vv.findViewById(R.id.spinnerstatus)
        spinnerstatus.onItemSelectedListener=this
        var id=0;
        val dd= activity?.let { ArrayAdapter(it,android.R.layout.simple_dropdown_item_1line,stat) }
        spinnerstatus.adapter=dd



        requireActivity().getSharedPreferences("user", AppCompatActivity.MODE_PRIVATE).apply {
            id=getInt("id",0)
            ethname1.setText(getString("name","").toString())
            ethnum1.setText(getString("mob","").toString())
            ethpass1.setText(getString("pass","").toString())
            ethemail1.setText(getString("email","").toString())
            ethdept.setText(getString("service","").toString()).toString()
            ethemail1.setText(getString("email","").toString())
            ethcity1.setText(getString("city","").toString())
            ethaddress1.setText(getString("address","").toString())

        }

        btnupdatehospital.setOnClickListener {
            val name=ethname1.text.toString()
            val num=ethnum1.text.toString()
            val add=ethaddress1.text.toString()
            val city=ethcity1.text.toString()
            val email=ethemail1.text.toString()
            val pass=ethpass1.text.toString()
            val dept=ethdept.text.toString()


                if(num.count()==10){


                    CoroutineScope(Dispatchers.IO).launch {

                        RetrofitClient.instance.updatehospital("$name","$num","$pass"
                        ,"$add","$sss","$dept",id,"userupdate")
                            .enqueue(object: Callback<DefaultResponse> {
                                override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                    t.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show() }
                                }
                                override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                    response.body()?.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show()}
                                    Toast.makeText(context, response.body()!!.message, Toast.LENGTH_SHORT).show()
                                    startActivity(Intent(activity, login::class.java))

                                }
                            })
                    }

                    //Toast.makeText(activity, "$lat,$long,$name,$num,$add,$city,$beds,$depart,$rating,", Toast.LENGTH_SHORT).show()
                }else{
                    ethnum1.setError("Enter hospital number properly")
                    Toast.makeText(activity,"Enter hospital number properly", Toast.LENGTH_SHORT).show()
                }

        }



        return vv
    }

    override fun onItemSelected(p0: AdapterView<*>?, p1: View?, p2: Int, p3: Long) {
       sss=stat.get(p2)

    }

    override fun onNothingSelected(p0: AdapterView<*>?) {
        TODO("Not yet implemented")
    }


}