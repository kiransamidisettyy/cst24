package com.ymts0579.integratedhealthcare

import com.ymts0579.aicte.model.hospitalresponse
import com.ymts0579.integratedhealthcare.model.Appointmentresponse
import com.ymts0579.integratedhealthcare.model.docloginresponse
import com.ymts0579.integratedhealthcare.model.doctorresponse
import com.ymts0579.integratedhealthcare.model.insuranceresponse
import com.ymts0579.model.model.DefaultResponse
import com.ymts0579.model.model.LoginResponse
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface Api {
    @FormUrlEncoded
    @POST("user.php")
    fun register(@Field("type") type:String, @Field("name") name:String,
        @Field("moblie")moblie:String, @Field("email")email :String,
        @Field("city") city:String,
        @Field("password") password:String,
        @Field("address")address :String,
        @Field("status") status:String,
        @Field("service")  service:String,
        @Field("condition") condition:String,
    ): Call<DefaultResponse>

    @FormUrlEncoded
    @POST("user.php")
    fun login(@Field("email") email:String, @Field("password") password:String,
              @Field("condition") condition:String): Call<LoginResponse>

    @FormUrlEncoded
    @POST("user.php")
    fun viewhospital( @Field("condition") condition:String,@Field("type") type:String,):Call<hospitalresponse>

    @FormUrlEncoded
    @POST("user.php")
    fun updatehospital(@Field("name") name:String, @Field("moblie")moblie:String, @Field("password") password:String,
                       @Field("address")address :String, @Field("status") status:String, @Field("service")  service:String,
                       @Field("id")id:Int, @Field("condition") condition:String,):Call<DefaultResponse>


    @FormUrlEncoded
    @POST("user.php")
    fun readbyplace(@Field("condition") condition:String,@Field("city") city:String,):Call<hospitalresponse>



    @FormUrlEncoded
    @POST("doctor.php")
    fun Adddoctor( @Field("name") name:String, @Field("moblie")moblie:String, @Field("password") password:String,
                 @Field("address")address :String,
                 @Field("status") status:String,
                 @Field("specialization")  specialization:String,
                 @Field("experiences")  experiences:String,
                 @Field("cost")cost:String,
                 @Field("hemail")hemail:String,
                 @Field("condition") condition:String,
    ): Call<DefaultResponse>


    @FormUrlEncoded
    @POST("doctor.php")
    fun updatedoc( @Field("name") name:String,
                   @Field("status") status:String,
                   @Field("condition") condition:String,
    ): Call<DefaultResponse>


    @FormUrlEncoded
    @POST("doctor.php")
    fun viewdoctor( @Field("hemail")hemail:String,@Field("condition") condition:String,):Call<doctorresponse>


    @FormUrlEncoded
    @POST("doctor.php")
    fun logindoctor(@Field("name") name:String, @Field("password") password:String,
                    @Field("condition") condition:String,):Call<docloginresponse>


    @FormUrlEncoded
    @POST("Appointment.php")
    fun addappointment(
        @Field("appointid") appointid:String,
        @Field("hemail") hemail: String,
        @Field("haddress") haddress:String,
        @Field("Dname") Dname:String,
        @Field("Dnumber") Dnumber:String,
        @Field("uemail") uemail:String,
        @Field("unum") unum:String,
        @Field("uname") uname:String,
        @Field("hours") hours:String,
        @Field("date") date:String,
        @Field("cost") cost:String,
        @Field("status") status:String,
        @Field("pstatus") pstatus:String,
        @Field("transactionid") transactionid:String,
        @Field("feedback") feedback:String,
        @Field("reason") reason:String,
        @Field("condition") condition:String,
        ):Call<DefaultResponse>

    @FormUrlEncoded
    @POST("Appointment.php")
    fun updatefeedback( @Field("id") id:Int, @Field("feedback") feedback:String,
                       @Field("condition") condition:String,):Call<DefaultResponse>


    @FormUrlEncoded
    @POST("Appointment.php")
    fun updatepayment( @Field("id") id:Int,@Field("pstatus") pstatus:String,
                       @Field("transactionid") transactionid:String, @Field("condition") condition:String,):Call<DefaultResponse>


    @FormUrlEncoded
    @POST("Appointment.php")
    fun doctoraccepted(  @Field("condition") condition:String,  @Field("status") status:String,@Field("id") id:Int,):Call<DefaultResponse>


    @FormUrlEncoded
    @POST("Appointment.php")
    fun viewhospitalappointment(  @Field("condition") condition:String,  @Field("hemail") hemail: String,):Call<Appointmentresponse>

    @FormUrlEncoded
    @POST("Appointment.php")
    fun adminfeedback(  @Field("condition") condition:String):Call<Appointmentresponse>

    @FormUrlEncoded
    @POST("Appointment.php")
    fun viewuserappointment(  @Field("condition") condition:String, @Field("uemail") uemail:String,):Call<Appointmentresponse>


    @FormUrlEncoded
    @POST("Appointment.php")
    fun viewdoctorappointment(  @Field("condition") condition:String,  @Field("Dname") Dname:String,):Call<Appointmentresponse>

    @FormUrlEncoded
    @POST("insurance.php")
    fun addinsurance(
         @Field("name") name:String,
        @Field("moblie")moblie:String,
        @Field("address")address :String,
         @Field("path") path:String,
        @Field("service")  service:String,
        @Field("condition") condition:String,
    ):Call<DefaultResponse>

    @FormUrlEncoded
    @POST("insurance.php")
    fun viewinsurance(
        @Field("condition") condition:String,
    ):Call<insuranceresponse>

    @FormUrlEncoded
    @POST("insurance.php")
    fun deleteinsurance(
        @Field("id") id:Int,
        @Field("condition") condition:String,
    ):Call<DefaultResponse>
}