package com.ymts0579.integratedhealthcare.user

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.adapter.adinsuranceadapter
import com.ymts0579.integratedhealthcare.adapter.userinsuranceadapter
import com.ymts0579.integratedhealthcare.model.insuranceresponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Userinsurance : AppCompatActivity() {
    lateinit var listadinsurance:RecyclerView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_userinsurance)
        listadinsurance=findViewById(R.id.adlistinsurance)
        listadinsurance.layoutManager = LinearLayoutManager(this)
        listadinsurance.setHasFixedSize(true)
        CoroutineScope(Dispatchers.IO).launch {

            RetrofitClient.instance.viewinsurance("viewcomplaints")
                .enqueue(object: Callback<insuranceresponse> {
                    override fun onFailure(call: Call<insuranceresponse>, t: Throwable) {

                        Toast.makeText(this@Userinsurance, t.message, Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(call: Call<insuranceresponse>, response: Response<insuranceresponse>) {
                        Toast.makeText(this@Userinsurance, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()
                        listadinsurance.adapter= userinsuranceadapter(this@Userinsurance,response.body()!!.user)
                    }
                })
        }
    }
}