package com.ymts0579.aicte.model

import com.ymts0579.model.model.User

data class hospitalresponse(val error: Boolean, val message:String, var user:ArrayList<User>)