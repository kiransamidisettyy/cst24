package com.ymts0579.integratedhealthcare

import android.content.Intent
import android.graphics.Bitmap
import android.net.Uri
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.MediaStore
import android.util.Base64
import android.widget.Button
import android.widget.EditText
import android.widget.ImageView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.snackbar.Snackbar
import com.ymts0579.aicte.model.hospitalresponse
import com.ymts0579.integratedhealthcare.adapter.adinsuranceadapter
import com.ymts0579.integratedhealthcare.adapter.hospitaladapter
import com.ymts0579.integratedhealthcare.model.insuranceresponse
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.io.ByteArrayOutputStream

class adminhealthcare : AppCompatActivity() {
    lateinit var addimage:ImageView
    lateinit var etiname:EditText
    lateinit var etinumber:EditText
    lateinit var etiaddress:EditText
    lateinit var etidescription:EditText
    lateinit var btnadd:Button
    lateinit var listadinsurance:RecyclerView
    var encoded=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_adminhealthcare)
        addimage=findViewById(R.id.addimage)
        etiname=findViewById(R.id.etiname)
        etinumber=findViewById(R.id.etinumber)
        etiaddress=findViewById(R.id.etiaddress)
        etidescription=findViewById(R.id.etidescription)
        btnadd=findViewById(R.id.btnadd)
        listadinsurance=findViewById(R.id.listadinsurance)
        listadinsurance.layoutManager = LinearLayoutManager(this)
        listadinsurance.setHasFixedSize(true)
        CoroutineScope(Dispatchers.IO).launch {

            RetrofitClient.instance.viewinsurance("viewcomplaints")
                .enqueue(object: Callback<insuranceresponse> {
                    override fun onFailure(call: Call<insuranceresponse>, t: Throwable) {

                        Toast.makeText(this@adminhealthcare, t.message, Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(call: Call<insuranceresponse>, response: Response<insuranceresponse>) {
                        Toast.makeText(this@adminhealthcare, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()
                        listadinsurance.adapter=adinsuranceadapter(this@adminhealthcare,response.body()!!.user)
                    }
                })
        }

        addimage.setOnClickListener {
            val intent = Intent(Intent.ACTION_GET_CONTENT)
            intent.setType("image/*")
            startActivityForResult(intent,90)

        }

        btnadd.setOnClickListener {
            val name=etiname.text.toString()
            val num=etinumber.text.toString()
            val add=etiaddress.text.toString()
            val des=etidescription.text.toString()

            if(name.isNotEmpty()&&num.isNotEmpty()&&add.isNotEmpty()&&des.isNotEmpty()){
                CoroutineScope(Dispatchers.IO).launch {
                    RetrofitClient.instance.addinsurance("$name","$num","$add",encoded,"$des","addcomplaints")
                        .enqueue(object: Callback<DefaultResponse> {
                            override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                t.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show() }
                            }
                            override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                response.body()?.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show()}

                            }
                        })
                }
            }

        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 90 && resultCode == RESULT_OK) {
            val tt1 = data?.data.toString()
            val uri = Uri.parse(tt1)
            addimage.setImageURI(uri)
            val bit= MediaStore.Images.Media.getBitmap(contentResolver,uri)
            val byte = ByteArrayOutputStream()
            bit.compress(Bitmap.CompressFormat.JPEG, 100, byte)
            val image = byte.toByteArray()
            encoded = android.util.Base64.encodeToString(image, Base64.DEFAULT)

        }
    }
}