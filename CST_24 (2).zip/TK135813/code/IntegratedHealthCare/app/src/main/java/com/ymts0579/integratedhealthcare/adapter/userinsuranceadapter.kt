package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.app.Notification
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.bumptech.glide.Glide
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.model.insurance
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class userinsuranceadapter (var context: Context, var listdata: ArrayList<insurance>):
    RecyclerView.Adapter<userinsuranceadapter.DataViewHolder>(){
    var id=0
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tviname=view.findViewById<TextView>(R.id.tviname)
        val tvinum=view.findViewById<TextView>(R.id.tvinum)
        val tviaddress=view.findViewById<TextView>(R.id.tviaddress)
        val tvides=view.findViewById<TextView>(R.id.tvides)
        val viewimg=view.findViewById<ImageView>(R.id.viewimg)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.insurancecard, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
        holder.tviname.text=listdata[position].name
        holder.tvinum.text=listdata[position].moblie
        holder.tviaddress.text=listdata[position].address
        holder.tvides.text=listdata[position].service
        val uri= Uri.parse(listdata[position].path.trim())
        Glide.with(context).load(uri).into(holder.viewimg)

        holder.itemView.setOnClickListener {
            val num=listdata[position].moblie
val k=Intent(Intent.ACTION_CALL, Uri.parse("tel:$num"))
            context.startActivity(k)
        }


    }




    override fun getItemCount() = listdata.size
}