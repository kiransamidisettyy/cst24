package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.app.DatePickerDialog
import android.app.TimePickerDialog
import android.content.Context
import android.telephony.gsm.SmsManager
import android.text.TextUtils
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.model.doctors
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import java.util.*
import kotlin.collections.ArrayList

class userdoctoradapter(var context: Context, var listdata: ArrayList<doctors>,var heamil:String,var haddress:String): RecyclerView.Adapter<userdoctoradapter.DataViewHolder>(){
    var id=0
    var mob=""
    var  email=""
    var name=""
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvname=view.findViewById<TextView>(R.id.tvname)
        val tvnum=view.findViewById<TextView>(R.id.tvnum)
        val tvspec=view.findViewById<TextView>(R.id.tvspec)
        val tvexp=view.findViewById<TextView>(R.id.tvexp)
        val preferences = view.getContext()


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.hdoctor, parent, false)
        return DataViewHolder(view)
    }

    @SuppressLint("CommitPrefEdits", "SetTextI18n")
    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
        holder.tvname.text=listdata[position].name
        holder.tvnum.text=listdata[position].moblie
        holder.tvspec.text=listdata[position].specialization
        holder.tvexp.text=listdata[position].experiences
        holder.preferences.getSharedPreferences("user", 0).apply {
           mob= getString ("mob","").toString()
            email=getString ("email","").toString()
            name=getString ("name","").toString()

        }


        holder.itemView.setOnClickListener {
            var c: Calendar = Calendar.getInstance()
            val dd=BottomSheetDialog(context,R.style.SheetDialog)
            dd.setContentView(R.layout.placeappointment)
            val tvappointid=dd.findViewById<TextView>(R.id.tvappointid)
            val tvname=dd.findViewById<TextView>(R.id.tvname)
            val tvnum=dd.findViewById<TextView>(R.id.tvnum)
            val tvspec=dd.findViewById<TextView>(R.id.tvspec)
            val etappdate=dd.findViewById<EditText>(R.id.etappdate)
            val etapphours=dd.findViewById<EditText>(R.id.etapphours)
            val etreason=dd.findViewById<EditText>(R.id.etreason)
            val btnappointmnet=dd.findViewById<Button>(R.id.btnappointmnet)
            val btnshowcost=dd.findViewById<Button>(R.id.btnshowcost)
            val tvcost=dd.findViewById<TextView>(R.id.tvcost)
            var v=(1000..9999).shuffled().last()
            Toast.makeText(context, "MED$v", Toast.LENGTH_SHORT).show()
            tvappointid!!.text="MED"+"$v"
            tvname!!.text=name
            tvnum!!.text=mob
            tvspec!!.text=email
            etappdate!!.setOnClickListener {
                DatePickerDialog(context, { view, year, month, dayOfMonth ->
                    var dt="$year-${month+1}-$dayOfMonth"
                    TimePickerDialog(context,
                        TimePickerDialog.OnTimeSetListener { view, hourOfDay, min ->
                        dt+=",$hourOfDay:$min"
                        etappdate.setText(dt)
                    },c.get(Calendar.HOUR),c.get(Calendar.MINUTE),false).show()
                },c.get(Calendar.YEAR),c.get(Calendar.MONTH),c.get(Calendar.DAY_OF_MONTH)).show() }
            btnshowcost!!.setOnClickListener {
                if(etapphours!!.text.toString().isEmpty()){
                    Toast.makeText(context, "Enter the fields", Toast.LENGTH_SHORT).show()
                }else{
                    val ii= etapphours.text.toString().toInt() * listdata[position].cost.toInt()
                    tvcost!!.text="₹${ii.toString()}"
                }
            }
            btnappointmnet!!.setOnClickListener {
                if(etapphours!!.text.toString().isEmpty()&&etappdate.text.toString().isEmpty()){
                    Toast.makeText(context, "Enter the fields", Toast.LENGTH_SHORT).show()
                }else{

                    CoroutineScope(Dispatchers.IO).launch {
                        RetrofitClient.instance.addappointment("${tvappointid.text.toString()}","${heamil}","${haddress}"
                        ,"${listdata[position].name}","${listdata[position].moblie}","${tvspec.text.toString()}",
                             "${tvnum.text.toString()}","${tvname.text.toString()}",
                            "${etapphours!!.text.toString()}","${etappdate.text.toString()}","${tvcost!!.text.toString()}",
                            "Pending","Not paid","not paid","none","${etreason!!.text.toString()}","register")
                            .enqueue(object: Callback<DefaultResponse> {
                                override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                    Toast.makeText(context, "${t.message}", Toast.LENGTH_SHORT).show()
                                }
                                override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                    Toast.makeText(context, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()
                                    if (TextUtils.isDigitsOnly(listdata[position].moblie)) {
                                        val smsManager: SmsManager = SmsManager.getDefault()
                                        smsManager.sendTextMessage(listdata[position].moblie, null, "You have Appointment with patient at ${etappdate.text.toString()}, Appointment id${tvappointid.text.toString()}for  more details check in Application", null, null)

                                    }
                                     dd.dismiss()
                                }
                            })
                    }
                }

            }

            //dd.setCancelable(false)
            dd.show()
        }

    }

    override fun getItemCount() = listdata.size
}
