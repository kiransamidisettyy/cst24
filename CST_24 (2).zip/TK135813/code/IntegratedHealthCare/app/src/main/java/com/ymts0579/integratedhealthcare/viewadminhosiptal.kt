package com.ymts0579.integratedhealthcare

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ImageView
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.aicte.model.hospitalresponse
import com.ymts0579.integratedhealthcare.adapter.hospitaladapter
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class viewadminhosiptal : Fragment() {

    lateinit var  list: RecyclerView
    lateinit var count: TextView

    var address = ""
    var place = ""
    var num=0

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       val view=inflater.inflate(R.layout.fragment_viewadminhosiptal, container, false)
        var num=0
        list=view.findViewById(R.id.adlisthospitals)
        count=view.findViewById(R.id.count)
        list.layoutManager = LinearLayoutManager(activity)
        list.setHasFixedSize(true)
        CoroutineScope(Dispatchers.IO).launch {

            RetrofitClient.instance.viewhospital("adminuser","Hospital")
                .enqueue(object: Callback<hospitalresponse> {
                    override fun onFailure(call: Call<hospitalresponse>, t: Throwable) {

                        Toast.makeText(context, t.message, Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(call: Call<hospitalresponse>, response: Response<hospitalresponse>) {
                        Toast.makeText(context, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()

                        activity?.let { hospitaladapter(it,response.body()!!.user).also { list.adapter = it } }
                        for (item in response.body()!!.user){
                            num++
                        }
                        count.setText("Number of Hospitals->$num")
                    }
                })
        }
        return view
    }


}