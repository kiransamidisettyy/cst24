package com.ymts0579.integratedhealthcare.user

import android.content.Intent
import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.ArrayAdapter
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.material.snackbar.Snackbar
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.login
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class userprofile : Fragment() {
    lateinit var   ethemail1: EditText
    lateinit var ethname1: EditText
    lateinit var  ethnum1: EditText

    lateinit var ethaddress1: EditText
    lateinit var  ethcity1: EditText
    lateinit var  ethpass1: EditText
    lateinit var btnupdatehospital: Button


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
        // Inflate the layout for this fragment
        var vv=inflater.inflate(R.layout.fragment_userprofile, container, false)
        ethemail1=vv.findViewById(R.id.ethemail1)
        ethname1=vv.findViewById(R.id.ethname1)
        ethnum1=vv.findViewById(R.id.ethnum1)
        ethaddress1=vv.findViewById(R.id.ethaddress1)
        ethcity1=vv.findViewById(R.id.ethcity1)
        ethpass1=vv.findViewById(R.id.ethpass1)
        btnupdatehospital=vv.findViewById(R.id.btnupdatehospital)
        var id=0;
        requireActivity().getSharedPreferences("user", AppCompatActivity.MODE_PRIVATE).apply {
            id=getInt("id",0)
            ethname1.setText(getString("name","").toString())
            ethnum1.setText(getString("mob","").toString())
            ethpass1.setText(getString("pass","").toString())
            ethemail1.setText(getString("email","").toString())
            ethemail1.setText(getString("email","").toString())
            ethcity1.setText(getString("city","").toString())
            ethaddress1.setText(getString("address","").toString())

        }

        btnupdatehospital.setOnClickListener {
            val name=ethname1.text.toString()
            val num=ethnum1.text.toString()
            val add=ethaddress1.text.toString()
            val pass=ethpass1.text.toString()

            if(num.count()==10){


                CoroutineScope(Dispatchers.IO).launch {

                    RetrofitClient.instance.updatehospital("$name","$num","$pass"
                        ,"$add","na","na",id,"userupdate")
                        .enqueue(object: Callback<DefaultResponse> {
                            override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                t.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show() }
                            }
                            override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                response.body()?.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show()}
                                Toast.makeText(context, response.body()!!.message, Toast.LENGTH_SHORT).show()
                                startActivity(Intent(activity, login::class.java))

                            }
                        })
                }

                //Toast.makeText(activity, "$lat,$long,$name,$num,$add,$city,$beds,$depart,$rating,", Toast.LENGTH_SHORT).show()
            }else{
                ethnum1.setError("Enter hospital number properly")
                Toast.makeText(activity,"Enter hospital number properly", Toast.LENGTH_SHORT).show()
            }

        }



        return vv
    }


}