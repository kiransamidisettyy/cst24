package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.model.doctors
import com.ymts0579.model.model.User

class hdoctoadapter(var context: Context, var listdata: ArrayList<doctors>): RecyclerView.Adapter<hdoctoadapter.DataViewHolder>(){
    var id=0
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
        val tvname=view.findViewById<TextView>(R.id.tvname)
        val tvnum=view.findViewById<TextView>(R.id.tvnum)
        val tvspec=view.findViewById<TextView>(R.id.tvspec)
        val tvexp=view.findViewById<TextView>(R.id.tvexp)


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.hdoctor, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
        holder.tvname.text=listdata[position].name
        holder.tvnum.text=listdata[position].moblie
        holder.tvspec.text=listdata[position].specialization
        holder.tvexp.text=listdata[position].experiences


    }




    override fun getItemCount() = listdata.size
}
