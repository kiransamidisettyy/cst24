package com.ymts0579.integratedhealthcare.Hospital

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.adapter.hdoctoadapter
import com.ymts0579.integratedhealthcare.model.doctorresponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class viewdoctor : AppCompatActivity() {
    lateinit var  list: RecyclerView
    lateinit var count: TextView
    var eamil=""
    var num=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewdoctor)

        list=findViewById(R.id.adlistdocotors)
        count=findViewById(R.id.count)
        list.layoutManager = LinearLayoutManager(this)
        list.setHasFixedSize(true)

        getSharedPreferences("user", AppCompatActivity.MODE_PRIVATE).apply {
            eamil= getString("email","").toString()
        }

        CoroutineScope(Dispatchers.IO).launch {

            RetrofitClient.instance.viewdoctor("$eamil","email")
                .enqueue(object: Callback<doctorresponse> {
                    override fun onFailure(call: Call<doctorresponse>, t: Throwable) {

                        Toast.makeText(this@viewdoctor, t.message, Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(call: Call<doctorresponse>, response: Response<doctorresponse>) {
                        Toast.makeText(this@viewdoctor, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()

                        list.adapter=hdoctoadapter(this@viewdoctor,response.body()!!.user)
                        for (item in response.body()!!.user){
                            num++
                        }
                        count.setText("Number of Doctor->$num")
                    }
                })
        }
    }
}