package com.ymts0579.model.model

data class User(var id:Int,
                var type:String,
                var name:String,
                var moblie:String,
                var email:String,
                var city:String,
               var  password:String,
                var address:String,
                var status:String,
                var service:String,)
