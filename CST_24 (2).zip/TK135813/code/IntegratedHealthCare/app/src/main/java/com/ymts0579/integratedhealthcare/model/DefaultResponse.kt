package com.ymts0579.model.model

 data class DefaultResponse (val error: Boolean, val message:String){
}