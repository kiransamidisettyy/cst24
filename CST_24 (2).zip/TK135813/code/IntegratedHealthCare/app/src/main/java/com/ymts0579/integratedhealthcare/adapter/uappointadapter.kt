package com.ymts0579.integratedhealthcare.adapter

import android.annotation.SuppressLint
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.google.android.material.snackbar.Snackbar
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.model.Appointments
import com.ymts0579.integratedhealthcare.user.userpayment
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class uappointadapter(var context: Context, var listdata: ArrayList<Appointments>):
    RecyclerView.Adapter<uappointadapter.DataViewHolder>(){
    var id=0
    class DataViewHolder(view: View) : RecyclerView.ViewHolder(view) {
       val  tvuapid=view.findViewById<TextView>(R.id.tvuapid)
       val  tvudoc=view.findViewById<TextView>(R.id.tvudoc)
       val  tvudnum=view.findViewById<TextView>(R.id.tvudnum)
       val  tvutime=view.findViewById<TextView>(R.id.tvutime)
       val  tvuhours=view.findViewById<TextView>(R.id.tvuhours)
       val   tvucost=view.findViewById<TextView>(R.id.tvucost)
       val  tvustatus=view.findViewById<TextView>(R.id.tvustatus)
       val  tvupay=view.findViewById<TextView>(R.id.tvupay)
       val  tvuaddresss=view.findViewById<TextView>(R.id.tvuaddresss)
        val btnupayemnt=view.findViewById<Button>(R.id.btnupayemnt)
       val  btnFeedback=view.findViewById<Button>(R.id.btnFeedback)

    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): DataViewHolder {
        val view = LayoutInflater.from(context).inflate(R.layout.userappoint, parent, false)
        return DataViewHolder(view)
    }

    override fun onBindViewHolder(holder: DataViewHolder, @SuppressLint("RecyclerView") position:Int) {
       val k=listdata[position]
        holder. tvuapid.text=k.appointid
        holder. tvudoc.text=k.Dname
        holder. tvudnum.text=k.Dnumber
        holder. tvutime.text=k.date
        holder. tvuhours.text=k.hours
        holder. tvucost.text=k.cost
        holder. tvustatus.text=k.status
        holder. tvupay.text=k.pstatus
        holder. tvuaddresss.text=k.haddress
        holder.itemView.setOnClickListener {
            var ii=Intent(context,userpayment::class.java)
            context.startActivity(ii)
        }
        holder.btnupayemnt.setOnClickListener {
            val dd= BottomSheetDialog(context,R.style.SheetDialog)
            dd.setContentView(R.layout.userpay)
            val pay=dd.findViewById<EditText>(R.id.etadupi)
            val btnaccept=dd.findViewById<Button>(R.id.btnaccept)
            btnaccept!!.setOnClickListener {
                CoroutineScope(Dispatchers.IO).launch {
                    RetrofitClient.instance.updatepayment(listdata[position].id,"Paid","${pay!!.text.toString()}","transupdate")
                        .enqueue(object: Callback<DefaultResponse> {
                            override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                t.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show() }
                            }
                            override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                Toast.makeText(context, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()
                                dd.dismiss()

                            }
                        })
                }
            }

            dd.show()

        }
        holder.btnFeedback.setOnClickListener {


            val dd= BottomSheetDialog(context,R.style.SheetDialog)
            dd.setContentView(R.layout.userfeedback)
            val pay=dd.findViewById<EditText>(R.id.etfeedback)
            val btnaccept=dd.findViewById<Button>(R.id.btnfeed)
            btnaccept!!.setOnClickListener {
                CoroutineScope(Dispatchers.IO).launch {
                    RetrofitClient.instance.updatefeedback(listdata[position].id,"${pay!!.text.toString()}","userfeedback")
                        .enqueue(object: Callback<DefaultResponse> {
                            override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                t.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show() }
                            }
                            override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                Toast.makeText(context, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()
                                dd.dismiss()

                            }
                        })
                }
            }

            dd.show()

        }

    }




    override fun getItemCount() = listdata.size
}