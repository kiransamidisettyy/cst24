package com.ymts0579.integratedhealthcare.Hospital

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.Toast
import com.google.android.material.snackbar.Snackbar
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.model.model.DefaultResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Doctor : AppCompatActivity() {
    lateinit var btnadddoctor:Button
    lateinit var showdoctor:Button
   lateinit var etdname:EditText
    lateinit var etdnum:EditText
    lateinit var etdaddress:EditText
    lateinit var etdspec:EditText
    lateinit var etdexper:EditText
    lateinit var etdcost:EditText
    lateinit var etdpass:EditText
    var eamil=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_doctor)
        btnadddoctor=findViewById(R.id.btnadddoctor)
        etdname=findViewById(R.id.etdname)
        etdnum=findViewById(R.id.etdnum)
        etdaddress=findViewById(R.id.etdaddress)
        etdspec=findViewById(R.id.etdspec)
        etdexper=findViewById(R.id.etdexper)
        etdcost=findViewById(R.id.etdcost)
        etdpass=findViewById(R.id.etdpass)
        showdoctor=findViewById(R.id.showdoctor)
        getSharedPreferences("user", AppCompatActivity.MODE_PRIVATE).apply {
           eamil= getString("email","").toString()
        }
        showdoctor.setOnClickListener { startActivity(Intent(this,viewdoctor::class.java)) }

        btnadddoctor.setOnClickListener {
           var name=etdname.text.toString()
           var num=etdnum.text.toString()
           var add= etdaddress.text.toString()
           var spec=etdspec.text.toString()
           var exp= etdexper.text.toString()
           var cost= etdcost.text.toString()
           var pass= etdpass.text.toString()

            if(name.isEmpty()&& num.isEmpty()&& add.isEmpty()
                &&spec.isEmpty()&&exp.isEmpty()&&cost.isEmpty()
                &&pass.isEmpty()){
                Toast.makeText(this, "Enter Doctor fields", Toast.LENGTH_SHORT).show()
            }else{
                if(num.length==10){
                    CoroutineScope(Dispatchers.IO).launch {
                        RetrofitClient.instance.Adddoctor("$name","$num","$pass","$add"
                        ,"available","$spec","$exp","$cost","$eamil","register")
                            .enqueue(object: Callback<DefaultResponse> {
                                override fun onFailure(call: Call<DefaultResponse>, t: Throwable) {
                                    t.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show() }
                                }
                                override fun onResponse(call: Call<DefaultResponse>, response: Response<DefaultResponse>) {
                                    response.body()?.message?.let { it1 -> Snackbar.make(it, it1, Snackbar.LENGTH_SHORT).show()}
                                    /*  etname.text!!.clear()
                                     etunum.text!!.clear()
                                     etemail.text!!.clear()
                                     etuaddress.text!!.clear()
                                     etucity.text!!.clear()
                                     etupass.text!!.clear()
                                     etupass1.text!!.clear()*/
                                }
                            })
                    }
                }else{
                    Toast.makeText(this, "Enter Doctor number correctly", Toast.LENGTH_SHORT).show()
                }
            }
        }



    }


}