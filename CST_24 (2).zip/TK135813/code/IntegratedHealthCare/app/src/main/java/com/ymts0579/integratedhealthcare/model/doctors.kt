package com.ymts0579.integratedhealthcare.model

data class doctors(
    var id:Int,
    var name:String,
    var moblie:String,
    var password:String,
    var address:String,
    var status:String,
    var specialization:String,
    var experiences:String,
    var cost:String,
    var hemail:String,
)
