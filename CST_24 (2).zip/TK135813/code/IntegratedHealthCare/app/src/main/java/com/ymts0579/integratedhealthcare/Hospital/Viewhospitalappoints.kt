package com.ymts0579.integratedhealthcare.Hospital

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.TextView
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.adapter.hosappointadapter
import com.ymts0579.integratedhealthcare.model.Appointmentresponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class Viewhospitalappoints : AppCompatActivity() {
    lateinit var  list: RecyclerView
    lateinit var count: TextView
    var eamil=""
    var address=""
    var num=0
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_viewhospitalappoints)

        getSharedPreferences("user", AppCompatActivity.MODE_PRIVATE).apply {
            eamil= getString("email","").toString()
        }

        list=findViewById(R.id.adlisthosapp)
        count=findViewById(R.id.count)
        list.layoutManager = LinearLayoutManager(this)
        list.setHasFixedSize(true)


        CoroutineScope(Dispatchers.IO).launch {

            RetrofitClient.instance.viewhospitalappointment("hospital","$eamil")
                .enqueue(object: Callback<Appointmentresponse> {
                    override fun onFailure(call: Call<Appointmentresponse>, t: Throwable) {

                        Toast.makeText(this@Viewhospitalappoints, t.message, Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(call: Call<Appointmentresponse>, response: Response<Appointmentresponse>) {
                        Toast.makeText(this@Viewhospitalappoints, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()

                        list.adapter= hosappointadapter(this@Viewhospitalappoints,response.body()!!.user)
                        for (item in response.body()!!.user){
                            num++
                        }
                        count.setText("Number of Appoitnments->$num")
                    }
                })
        }

    }
}