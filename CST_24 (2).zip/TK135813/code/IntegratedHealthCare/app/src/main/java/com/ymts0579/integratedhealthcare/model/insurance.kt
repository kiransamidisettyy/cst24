package com.ymts0579.integratedhealthcare.model

 data class insurance(
    var id:Int,
    var name:String,
    var moblie:String,
    var address:String,
    var path:String,
    var service:String,

) {
}