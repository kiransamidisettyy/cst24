package com.ymts0579.integratedhealthcare

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.Button
import android.widget.EditText
import android.widget.TextView
import android.widget.Toast
import com.google.android.material.bottomsheet.BottomSheetDialog
import com.ymts0579.integratedhealthcare.Admin.Admindashboard
import com.ymts0579.integratedhealthcare.Doctor.DoctorDashboard
import com.ymts0579.integratedhealthcare.Hospital.Hospitaldashboard
import com.ymts0579.integratedhealthcare.model.docloginresponse
import com.ymts0579.integratedhealthcare.user.userdashboard
import com.ymts0579.model.model.LoginResponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class login : AppCompatActivity() {
    lateinit var etloginid: EditText
    lateinit var etloginpassword: EditText
    lateinit var doctorlogin:TextView
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_login)
        etloginid=findViewById(R.id.etloginid)
        etloginpassword=findViewById(R.id.etloginpassword)
        doctorlogin=findViewById(R.id.doctorlogin)

        doctorlogin.setOnClickListener {
            val dialog = BottomSheetDialog(this,R.style.SheetDialog)
            val view = layoutInflater.inflate(R.layout.doclogin, null)
            val etdocname=view.findViewById<EditText>(R.id.etdocname)
            val etdocpass=view.findViewById<EditText>(R.id.etdocpass)
            val btnlogindoc=view.findViewById<Button>(R.id.btnlogindoc)
            val name=etdocname.text.toString()
            val pass=etdocpass.text.toString()
            btnlogindoc.setOnClickListener {
                if(etdocname.text.toString().isNotEmpty()&&etdocpass.text.toString().isNotEmpty()){
                    CoroutineScope(Dispatchers.IO).launch {
                        RetrofitClient.instance.logindoctor(etdocname.text.toString(),etdocpass.text.toString(),"login")
                            .enqueue(object: Callback<docloginresponse> {
                                override fun onResponse(
                                    call: Call<docloginresponse>, response: Response<docloginresponse>
                                ) {
                                    if(!response.body()?.error!!){
                                        val type=response.body()?.user
                                        getSharedPreferences("doctor", MODE_PRIVATE).edit().apply {
                                            putString("name",type!!.name)
                                            putString("status",type.status)
                                            apply()
                                        }
                                        var ii=Intent(this@login,DoctorDashboard::class.java)
                                        startActivity(ii)
                                        Toast.makeText(applicationContext, response.body()?.message, Toast.LENGTH_SHORT).show()

                                    }

                                }

                                override fun onFailure(call: Call<docloginresponse>, t: Throwable) {
                                    Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()


                                }

                            })
                    }

                }else{
                    Toast.makeText(this, "enter your fields", Toast.LENGTH_SHORT).show()
                    etdocname.setError("Enter your Name")
                    etdocpass.setError("Enter your Password")

                }
            }
            dialog.setContentView(view)
            dialog.show()

        }
    }

    fun register(view: View) {
        startActivity(Intent(this,Register::class.java))
    }

    fun login(view: View) {
        val email = etloginid.text.toString()
        val pass = etloginpassword.text.toString()
        if (email.isEmpty() && pass.isEmpty()) {
            etloginid.setError("Enter your Email")
            etloginpassword.setError("Enter your password")
        } else {
            if (email == "admin" && pass == "admin") {
                getSharedPreferences("admin", MODE_PRIVATE).edit().apply {
                    putString("ad", email)
                    apply()
                }
                startActivity(Intent(this, Admindashboard::class.java))
                finish()
            }else{
                CoroutineScope(Dispatchers.IO).launch {
                    RetrofitClient.instance.login(email,pass,"login")
                        .enqueue(object: Callback<LoginResponse> {
                            override fun onResponse(
                                call: Call<LoginResponse>, response: Response<LoginResponse>
                            ) {
                                if(!response.body()?.error!!){
                                    val type=response.body()?.user
                                    if (type!=null) {
                                        getSharedPreferences("user", MODE_PRIVATE).edit().apply {
                                            putString("mob",type.moblie)
                                            putString("pass",type.password)
                                            putString("email",type.email)
                                            putString("name",type.name)
                                            putString("address",type.address)
                                            putString("city",type.city)
                                            putString("type",type.type)
                                            putString("service",type.service)
                                            putInt("id",type.id)
                                            apply()
                                        }

                                        val kk=type.type

                                        if(kk=="Hospital"){
                                            startActivity(Intent(applicationContext,Hospitaldashboard::class.java))
                                        }else if(kk=="user"){
                                            startActivity(Intent(applicationContext, userdashboard::class.java))
                                            finish()
                                        }



                                    }
                                }else{
                                    Toast.makeText(applicationContext, response.body()?.message, Toast.LENGTH_SHORT).show()
                                }

                            }

                            override fun onFailure(call: Call<LoginResponse>, t: Throwable) {
                                Toast.makeText(applicationContext, t.message, Toast.LENGTH_LONG).show()


                            }

                        })
                }

            }
        }


    }
}