package com.ymts0579.integratedhealthcare.Doctor

import android.os.Bundle
import androidx.fragment.app.Fragment
import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.ymts0579.aicte.model.hospitalresponse
import com.ymts0579.integratedhealthcare.R
import com.ymts0579.integratedhealthcare.RetrofitClient
import com.ymts0579.integratedhealthcare.adapter.docadapter
import com.ymts0579.integratedhealthcare.adapter.hospitaladapter
import com.ymts0579.integratedhealthcare.model.Appointmentresponse
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response


class Doctorappointment : Fragment() {

     lateinit var adlistdocappoint:RecyclerView
     var name=""
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)

    }

    override fun onCreateView(
        inflater: LayoutInflater, container: ViewGroup?,
        savedInstanceState: Bundle?
    ): View? {
       var ii=inflater.inflate(R.layout.fragment_doctorappointment, container, false)
           requireActivity().getSharedPreferences("doctor", AppCompatActivity.MODE_PRIVATE).apply {
           name= getString("name","").toString()
            getString("status","")
        }
        adlistdocappoint=ii.findViewById(R.id.adlistdocappoint)
        adlistdocappoint.layoutManager = LinearLayoutManager(activity)
        adlistdocappoint.setHasFixedSize(true)

        CoroutineScope(Dispatchers.IO).launch {

            RetrofitClient.instance.viewdoctorappointment("Doctor","${name}")
                .enqueue(object: Callback<Appointmentresponse> {
                    override fun onFailure(call: Call<Appointmentresponse>, t: Throwable) {

                        Toast.makeText(context, t.message, Toast.LENGTH_SHORT).show()
                    }
                    override fun onResponse(call: Call<Appointmentresponse>, response: Response<Appointmentresponse>) {
                        Toast.makeText(context, "${response.body()!!.message}", Toast.LENGTH_SHORT).show()

                        activity?.let { docadapter(it,response.body()!!.user).also { adlistdocappoint.adapter = it } }


                    }
                })
        }

        return ii
    }

}